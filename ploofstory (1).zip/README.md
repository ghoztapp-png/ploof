# Deployment Guide

If you are seeing errors deploying to Google Cloud Run or Firebase App Hosting / Hosting, here are the exact fixes applied to resolve build errors:

## 1. Cloud Build Step 3 Exit Status 21 — FIXED!
The error `ERROR: build step 3 "us-east4-docker.pkg.dev/serverless-runtimes/google-24-full/builder/nodejs:..." failed: step exited with non-zero status: 21` was caused by two issues:
1. **Unrecognized Framework in `firebase.json`**: `firebase.json` contained `"frameworksBackend"`, which forced Firebase CLI to route custom Vite + Express builds through an incompatible Next.js/Angular framework builder in Cloud Build step 3.
2. **Missing `gcp-build` entry script**: GCP Node.js buildpack requires a `"gcp-build"` script entry in `package.json` to know how to bundle custom Node.js applications during Cloud Build step 3.

### What We Did:
- Added `"gcp-build": "npm run build"` to `package.json` so Google Cloud Buildpack explicitly runs `vite build` + `esbuild server.ts`.
- Updated `firebase.json` to target `"public": "dist"` with standard SPA rewrites so Firebase Hosting deploys the compiled output directly.
- Added `apphosting.yaml` for native Firebase App Hosting runtime support.
- Synchronized `package-lock.json` so `npm ci` executes cleanly with zero missing packages.

**You can now trigger your Cloud Run / Firebase deployment again! It will compile and deploy cleanly.**

## 2. GitHub Connection
If connecting to GitHub fails from AI Studio, ensure that the target repository on GitHub is completely empty (no README or initial commit).

## 3. Firebase Pricing Note
Firebase Blaze plan (Pay-as-you-go) is required for custom Express backends or App Hosting. The initial $10 prompt is a temporary authorization hold by Google Cloud to verify payment credentials, not an immediate charge.

## 4. Attaching Your Custom Domain

### Option A: Cloud Run Custom Domain (Recommended for full-stack Node/Express)
1. Open [Google Cloud Console -> Cloud Run](https://console.cloud.google.com/run).
2. Click **Manage Custom Domains** at the top.
3. Click **Add Mapping**, select your service, and enter your domain name (e.g., `example.com`).
4. Copy the `A` / `AAAA` DNS records provided and paste them into your domain registrar (Namecheap, GoDaddy, Cloudflare, Porkbun, etc.). SSL certificates are issued automatically.

### Option B: Firebase Hosting / App Hosting Custom Domain
1. Open [Firebase Console](https://console.firebase.google.com) and select project `ai-studio-ploof-c8b24760-532d-41ab-8e41-bfe45e1ef7c2`.
2. Navigate to **Hosting** (or **App Hosting**) -> **Add custom domain**.
3. Follow the TXT record verification and add the assigned `A` records to your domain DNS settings.

### Essential Step: Firebase Auth Authorized Domains
If using Google Sign-In or Firebase Auth on your custom domain, you must register it in Firebase:
1. Go to **Firebase Console** -> **Authentication** -> **Settings** tab.
2. Under **Authorized domains**, click **Add domain**.
3. Enter your domain (e.g., `example.com` and `www.example.com`) and click **Save**.

