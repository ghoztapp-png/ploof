const config = require('./firebase-applet-config.json');
const projectId = config.projectId;
const databaseId = config.firestoreDatabaseId;

console.log(`URL: https://firestore.googleapis.com/v1/projects/${projectId}/databases/${databaseId}/documents/users/testUser`);
