const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetStr = `              {/* Features / Value Prop Section */}`;
const replaceStr = `              {!isSubscribed && (
                <>
                  {/* Features / Value Prop Section */}`;

code = code.replace(targetStr, replaceStr);

const targetStrEnd = `              {/* FAQ & Support Section */}`;
const replaceStrEnd = `                </>
              )}

              {/* FAQ & Support Section */}`;

code = code.replace(targetStrEnd, replaceStrEnd);

fs.writeFileSync('src/App.tsx', code);
