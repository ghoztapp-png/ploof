const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Replace fetch('/api/generate' with ID token injection
code = code.replace(/fetch\('\/api\/generate',\s*\{/g, `fetch('/api/generate', {
          headers: {
            'Content-Type': 'application/json',
            ...(auth.currentUser ? { 'Authorization': \`Bearer \${await auth.currentUser.getIdToken()}\` } : {})
          },`);

// Remove existing Content-Type header if present inside the fetch since we added it above
code = code.replace(/headers:\s*\{\s*'Content-Type':\s*'application\/json'\s*\},/g, '');

// Same for /api/continue
code = code.replace(/fetch\('\/api\/continue',\s*\{/g, `fetch('/api/continue', {
          headers: {
            'Content-Type': 'application/json',
            ...(auth.currentUser ? { 'Authorization': \`Bearer \${await auth.currentUser.getIdToken()}\` } : {})
          },`);

fs.writeFileSync('src/App.tsx', code);
