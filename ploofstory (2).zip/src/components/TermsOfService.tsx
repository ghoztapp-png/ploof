import React from 'react';
import { ArrowLeft } from 'lucide-react';

export default function TermsOfService({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans p-8 md:p-16 max-w-4xl mx-auto relative z-10">
      <button 
        onClick={onBack}
        className="flex items-center text-indigo-400 hover:text-indigo-300 mb-8 transition-colors"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to App
      </button>
      
      <h1 className="text-3xl font-bold text-white mb-6">Terms of Service</h1>
      <p className="text-sm text-slate-400 mb-8">Last Updated: July 2026</p>

      <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
        <section>
          <h2 className="text-lg font-semibold text-white mb-3">1. Acceptance of Terms</h2>
          <p>By accessing or using Ploof Bedtime Stories, you agree to be bound by these Terms of Service. If you disagree with any part of the terms, you may not access the service.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">2. Description of Service</h2>
          <p>Ploof Bedtime Stories provides an AI-powered story generation tool designed to create custom bedtime stories based on user inputs.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">3. Subscriptions and Payments</h2>
          <p>We offer a paid subscription plan for unlimited story generation. Payments are processed securely via Stripe. You can cancel your subscription at any time through the customer portal.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">4. User Content</h2>
          <p>You retain all rights to the inputs you provide. By using the app, you grant us a license to process these inputs solely to generate and store stories on your behalf.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">5. Disclaimer of Warranties</h2>
          <p>The service is provided "as is" and "as available" without any warranties of any kind. We do not guarantee that the AI-generated content will always be perfectly accurate, error-free, or suitable for all audiences, though we implement strict safety guidelines.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">6. Limitation of Liability</h2>
          <p>In no event shall Ploof Bedtime Stories be liable for any indirect, incidental, special, consequential, or punitive damages arising out of your use of the service.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">7. Contact Us</h2>
          <p>If you have any questions about these Terms, please contact us at ghozt.app@gmail.com.</p>
        </section>
      </div>
    </div>
  );
}
