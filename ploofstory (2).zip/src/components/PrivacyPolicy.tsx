import React from 'react';
import { ArrowLeft } from 'lucide-react';

export default function PrivacyPolicy({ onBack }: { onBack: () => void }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans p-8 md:p-16 max-w-4xl mx-auto relative z-10">
      <button 
        onClick={onBack}
        className="flex items-center text-indigo-400 hover:text-indigo-300 mb-8 transition-colors"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to App
      </button>
      
      <h1 className="text-3xl font-bold text-white mb-6">Privacy Policy</h1>
      <p className="text-sm text-slate-400 mb-8">Last Updated: July 2026</p>

      <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
        <section>
          <h2 className="text-lg font-semibold text-white mb-3">1. Introduction</h2>
          <p>Welcome to Ploof Bedtime Stories ("we," "our," or "us"). We are committed to protecting your privacy and ensuring you have a positive experience on our app.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">2. Information We Collect</h2>
          <p className="mb-2">We collect the following types of information:</p>
          <ul className="list-disc pl-5 space-y-1 text-slate-400">
            <li><strong>Account Information:</strong> If you create an account, we collect your email address and profile information provided by Google Authentication.</li>
            <li><strong>Story Inputs:</strong> Information you input to generate stories, such as names, favorite animals, and settings.</li>
            <li><strong>Usage Data:</strong> Information about how you use our app, including generated stories saved to your library and subscription status.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">3. How We Use Your Information</h2>
          <ul className="list-disc pl-5 space-y-1 text-slate-400">
            <li>To provide and maintain our service, including AI story generation.</li>
            <li>To process payments and manage subscriptions via Stripe.</li>
            <li>To improve and personalize your experience.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">4. Data Sharing</h2>
          <p>We do not sell your personal data. We share data only with essential third-party service providers (such as Google GenAI, Firebase, and Stripe) strictly for the purpose of operating the application.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">5. Children's Privacy</h2>
          <p>Ploof Bedtime Stories is designed to be used by parents and guardians. We do not knowingly collect personally identifiable information directly from children under 13 without parental consent.</p>
        </section>

        <section>
          <h2 className="text-lg font-semibold text-white mb-3">6. Contact Us</h2>
          <p>If you have any questions about this Privacy Policy, please contact us at ghozt.app@gmail.com.</p>
        </section>
      </div>
    </div>
  );
}
