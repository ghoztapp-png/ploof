import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Moon, Star, BookOpen, Loader2, Bookmark, BookmarkCheck, Library, X, Trash2, Sun, Download, Share2, Check, ChevronDown, MessageSquare, AlertTriangle, ArrowLeft, WifiOff, CloudMoon, Wand2, Heart } from 'lucide-react';
import Markdown from 'react-markdown';
import { auth, googleProvider, signInWithPopup, signOut, db, handleFirestoreError, OperationType } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, getDocs, orderBy, serverTimestamp, deleteDoc } from 'firebase/firestore';

interface SavedStory {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
  date: string;
}

import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';

type ViewState = 'home' | 'tos' | 'privacy';

export default function App() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('home');
  
  const [formData, setFormData] = useState({
    childName: '',
    favoriteAnimal: '',
    setting: '',
    magicalElement: '',
    storyLength: 'medium'
  });
  const [story, setStory] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showStory, setShowStory] = useState(false);
  const [savedStories, setSavedStories] = useState<SavedStory[]>([]);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  
  // Story Continuation states
  const [isContinuing, setIsContinuing] = useState(false);
  const [chapterCount, setChapterCount] = useState(1);
  const [continueError, setContinueError] = useState<string | null>(null);
  
  // FAQ & Support state
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);
  
  // Settings
  const [isNightMode, setIsNightMode] = useState(false);
  
  // PWA Install State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBtn, setShowInstallBtn] = useState(false);

  // Paywall & Subscription states
  const [generationsCount, setGenerationsCount] = useState(0);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'form' | 'loading' | 'success'>('form');

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowInstallBtn(false);
    }
    setDeferredPrompt(null);
  };

  // Checkout form fields
  const [checkoutEmail, setCheckoutEmail] = useState('');
  const [checkoutCard, setCheckoutCard] = useState('');
  const [checkoutExpiry, setCheckoutExpiry] = useState('');
  const [checkoutCvc, setCheckoutCvc] = useState('');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');
    const checkoutCanceled = urlParams.get('checkout_canceled');

    if (sessionId) {
      setCheckoutStep('loading');
      setIsCheckoutOpen(true);
      fetch('/api/verify-checkout-session', {
        method: 'POST',
        
        body: JSON.stringify({ sessionId })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          saveSubscriptionStatus(true);
          setCheckoutStep('success');
        } else {
          setCheckoutStep('form');
        }
        window.history.replaceState({}, document.title, window.location.pathname);
      })
      .catch(err => {
        console.error(err);
        setCheckoutStep('form');
      });
    }

    if (checkoutCanceled) {
      setIsCheckoutOpen(true);
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBtn(true);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setGenerationsCount(data.generationsCount || 0);
            setIsSubscribed(data.isSubscribed || false);
          } else {
            const savedCount = parseInt(localStorage.getItem('ploof_generations_count') || '0', 10);
            const savedSub = localStorage.getItem('ploof_subscribed') === 'true';
            await setDoc(doc(db, 'users', currentUser.uid), {
              generationsCount: savedCount,
              isSubscribed: savedSub
            });
            setGenerationsCount(savedCount);
            setIsSubscribed(savedSub);
          }
          
          const storiesQuery = query(collection(db, 'users', currentUser.uid, 'stories'), orderBy('createdAt', 'desc'));
          const storiesSnapshot = await getDocs(storiesQuery);
          const stories: SavedStory[] = [];
          storiesSnapshot.forEach((sDoc) => {
            const data = sDoc.data();
            stories.push({
              id: sDoc.id,
              title: data.title,
              content: data.content,
              imageUrl: data.imageUrl,
              date: data.date
            });
          });
          
          if (stories.length > 0) {
            setSavedStories(stories);
          } else {
            const saved = localStorage.getItem('ploof_stories');
            if (saved) {
              try {
                const localStories = JSON.parse(saved);
                setSavedStories(localStories);
                for (const s of localStories) {
                  await setDoc(doc(db, 'users', currentUser.uid, 'stories', s.id), {
                    userId: currentUser.uid,
                    title: s.title,
                    content: s.content,
                    imageUrl: s.imageUrl,
                    date: s.date,
                    createdAt: serverTimestamp()
                  });
                }
              } catch (e) {}
            }
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${currentUser.uid}`);
        }
      } else {
        const saved = localStorage.getItem('ploof_stories');
        if (saved) {
          try {
            setSavedStories(JSON.parse(saved));
          } catch (e) {}
        }
        const count = localStorage.getItem('ploof_generations_count');
        if (count) {
          setGenerationsCount(parseInt(count, 10));
        }
        const sub = localStorage.getItem('ploof_subscribed');
        if (sub === 'true') {
          setIsSubscribed(true);
        }
      }
    });
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribeAuth();
    };
  }, []);

  const saveGenerationsCount = async (newCount: number) => {
    setGenerationsCount(newCount);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), { generationsCount: newCount }, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    } else {
      localStorage.setItem('ploof_generations_count', newCount.toString());
    }
  };

  const saveSubscriptionStatus = async (status: boolean) => {
    setIsSubscribed(status);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), { isSubscribed: status }, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${user.uid}`);
      }
    } else {
      localStorage.setItem('ploof_subscribed', status.toString());
    }
  };

  const handleDownload = () => {
    const title = story.match(/^#\s+(.+)/m)?.[1] || `${formData.childName || 'My'}'s Tale`;
    const safeTitle = title.replace(/[^a-z0-9]/gi, '_').toLowerCase();
    
    const blob = new Blob([story], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${safeTitle}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleShare = async () => {
    const title = story.match(/^#\s+(.+)/m)?.[1] || `${formData.childName || 'My'}'s Tale`;
    
    const copyToClipboard = async () => {
      try {
        await navigator.clipboard.writeText(story);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy', err);
      }
    };

    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: story,
        });
      } catch (err: any) {
        // If the user didn't cancel, fallback to copy
        if (err.name !== 'AbortError') {
          copyToClipboard();
        }
      }
    } else {
      copyToClipboard();
    }
  };

  const handleSave = async () => {
    const title = story.match(/^#\s+(.+)/m)?.[1] || `${formData.childName || 'My'}'s Tale`;
    const newStory: SavedStory = {
      id: Date.now().toString(),
      title,
      content: story,
      imageUrl,
      date: new Date().toISOString()
    };
    const updated = [newStory, ...savedStories];
    setSavedStories(updated);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid, 'stories', newStory.id), {
          userId: user.uid,
          title: newStory.title,
          content: newStory.content,
          imageUrl: newStory.imageUrl || '',
          date: newStory.date,
          createdAt: serverTimestamp()
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `users/${user.uid}/stories/${newStory.id}`);
      }
    } else {
      localStorage.setItem('ploof_stories', JSON.stringify(updated));
    }
    setIsSaved(true);
  };

  const handleDeleteSaved = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = savedStories.filter(s => s.id !== id);
    setSavedStories(updated);
    if (user) {
      try {
        await deleteDoc(doc(db, 'users', user.uid, 'stories', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${user.uid}/stories/${id}`);
      }
    } else {
      localStorage.setItem('ploof_stories', JSON.stringify(updated));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.childName || !formData.favoriteAnimal) return;

    // Check limit first
    if (!isSubscribed && generationsCount >= 3) {
      setCheckoutStep('form');
      setIsCheckoutOpen(true);
      return;
    }
    
    setIsGenerating(true);
    setStory('');
    setImageUrl('');
    setIsSaved(false);
    setError(null);
    setChapterCount(1);
    setContinueError(null);
    
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(auth.currentUser ? { 'Authorization': `Bearer ${await auth.currentUser.getIdToken()}` } : {})
        },
        body: JSON.stringify(formData),
      });
      
      const data = await response.json();
      
      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to generate story');
      }

      if (data.story) {
        setStory(data.story);
        
        const title = data.story.match(/^#\s+(.+)/m)?.[1] || `${formData.childName || 'My'}'s Tale`;
        const prompt = `A cute, adorable 3D Pixar animation style children's book illustration for a bedtime story about ${formData.favoriteAnimal} titled "${title}", soft glowing light, friendly, vibrant but soothing pastel colors, high quality, masterpiece, bright edge-to-edge, no vignette, no dark edges, no text.`;
        setImageUrl(`https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=400&nologo=true`);
        
        setShowStory(true);

        // Increment count if not subscribed
        if (!isSubscribed) {
          saveGenerationsCount(generationsCount + 1);
        }
      }
    } catch (err: any) {
      console.error('Failed to generate story', err);
      setError("The magic clouds are a bit busy right now. Please try again in a moment.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSurpriseMe = () => {
    const surprises = [
      { name: "Leo", animal: "A sleepy little bear", setting: "The Starry Mountains", magic: "A glowing lantern" },
      { name: "Mia", animal: "A gentle fox", setting: "The Whispering Woods", magic: "A silver leaf" },
      { name: "Sam", animal: "A brave little owl", setting: "The Dreamy Clouds", magic: "A moonbeam" },
      { name: "Zoe", animal: "A quiet bunny", setting: "The Sleepy Meadow", magic: "A golden acorn" },
      { name: "Oliver", animal: "A tiny dragon", setting: "The Crystal Caves", magic: "A magic spark" },
      { name: "Ava", animal: "A fluffy kitten", setting: "The Moonlit Garden", magic: "A shooting star" },
      { name: "Noah", animal: "A brave little turtle", setting: "The Coral Reefs", magic: "A glowing pearl" },
      { name: "Emma", animal: "A curious squirrel", setting: "The Giant Oak Tree", magic: "A magic compass" },
      { name: "Liam", animal: "A playful puppy", setting: "The Secret Garden", magic: "A golden key" },
      { name: "Sophia", animal: "A graceful swan", setting: "The Silver Lake", magic: "A crystal feather" },
      { name: "Jackson", animal: "A clever raccoon", setting: "The Starlight City", magic: "A pocket watch" },
      { name: "Isabella", animal: "A beautiful butterfly", setting: "The Enchanted Forest", magic: "A drop of morning dew" },
      { name: "Lucas", animal: "A friendly frog", setting: "The Lilypad Pond", magic: "A lily flower crown" },
      { name: "Aria", animal: "A tiny songbird", setting: "The Melody Valley", magic: "A musical note" },
      { name: "Ethan", animal: "A sleepy koala", setting: "The Eucalyptus Grove", magic: "A dream catcher" },
      { name: "Charlotte", animal: "A graceful deer", setting: "The Winter Woods", magic: "A snowflake crystal" }
    ];
    const surprise = surprises[Math.floor(Math.random() * surprises.length)];
    
    setFormData({
      childName: surprise.name,
      favoriteAnimal: surprise.animal,
      setting: surprise.setting,
      magicalElement: surprise.magic,
      storyLength: 'medium'
    });
  };

  const handleContinueStory = async () => {
    // Check limit first
    if (!isSubscribed && generationsCount >= 3) {
      setCheckoutStep('form');
      setIsCheckoutOpen(true);
      return;
    }

    setIsContinuing(true);
    setContinueError(null);

    try {
      const response = await fetch('/api/continue', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(auth.currentUser ? { 'Authorization': `Bearer ${await auth.currentUser.getIdToken()}` } : {})
        },
        body: JSON.stringify({
          ...formData,
          previousStory: story
        }),
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to continue story');
      }

      if (data.story) {
        // Append the continuation
        const continuationText = data.story;
        setStory(prev => prev + "\n\n" + continuationText);
        setChapterCount(prev => prev + 1);
        setIsSaved(false); // Let them save the expanded book!

        // Increment count if not subscribed
        if (!isSubscribed) {
          saveGenerationsCount(generationsCount + 1);
        }
      }
    } catch (err: any) {
      console.error('Failed to continue story', err);
      setContinueError("The weavers' spindle got slightly tangled. Please try again in a moment.");
    } finally {
      setIsContinuing(false);
    }
  };

  const handleReset = () => {
    setShowStory(false);
    setTimeout(() => {
      setStory('');
      setChapterCount(1);
      setContinueError(null);
    }, 500); // Wait for transition
  };

  if (view === 'privacy') return <PrivacyPolicy onBack={() => setView('home')} />;
  if (view === 'tos') return <TermsOfService onBack={() => setView('home')} />;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30 overflow-x-hidden relative">
      {/* Night Mode Overlay */}
      <div 
        className={`fixed inset-0 z-50 pointer-events-none transition-colors duration-1000 mix-blend-multiply ${
          isNightMode ? 'bg-amber-600/40' : 'bg-transparent'
        }`} 
      />

      {/* Background ambient shapes */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-900/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-purple-900/10 rounded-full blur-[150px]" />
      </div>

      {/* Top Navigation */}
      <div className="fixed top-0 inset-x-0 p-4 sm:p-6 flex flex-col sm:flex-row justify-between items-center z-30 pointer-events-none gap-3 sm:gap-0">
        {/* Left Status Badge */}
        <div className="pointer-events-auto">
          {!isSubscribed ? (
            <button
              onClick={() => {
                setCheckoutStep('form');
                setIsCheckoutOpen(true);
              }}
              className="bg-gradient-to-r from-indigo-500/20 to-purple-500/20 backdrop-blur-md border border-indigo-500/30 hover:border-indigo-500/60 text-indigo-200 hover:text-white px-4 py-2.5 rounded-full text-xs font-semibold flex items-center shadow-lg transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1.5 animate-pulse text-indigo-400" />
              {3 - generationsCount > 0 
                ? `${3 - generationsCount} Free Stories Left` 
                : 'Limit Reached! Get Premium'
              }
            </button>
          ) : (
            <div className="bg-gradient-to-r from-amber-500/20 to-yellow-500/20 backdrop-blur-md border border-amber-500/30 text-amber-200 px-4 py-2.5 rounded-full text-xs font-semibold flex items-center shadow-lg">
              <Star className="w-3.5 h-3.5 mr-1.5 text-amber-400 fill-amber-400" />
              Ploof Premium Active
            </div>
          )}
        </div>

        {/* Right Buttons */}
        <div className="flex items-center space-x-2 sm:space-x-3 pointer-events-auto">
          <button
            onClick={() => {
              if (deferredPrompt) {
                handleInstallClick();
              } else {
                alert("To install this app:\n\n1. Open the app in a new tab (if in preview).\n2. On iOS: Tap Share -> 'Add to Home Screen'.\n3. On Chrome/Android: Tap Menu -> 'Install App'.");
              }
            }}
            className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-semibold px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm flex items-center shadow-lg shadow-emerald-500/20 border border-emerald-300/40 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Download className="w-4 h-4 mr-1.5 stroke-[2.5]" />
            <span className="hidden sm:inline">Install App</span>
            <span className="sm:hidden">Install</span>
          </button>
          <button
            onClick={() => setIsNightMode(!isNightMode)}
            className={`bg-slate-900/50 backdrop-blur-md border border-slate-800 hover:text-white p-2 sm:p-2.5 rounded-full text-xs sm:text-sm font-medium flex items-center shadow-lg transition-all ${isNightMode ? 'text-amber-400 border-amber-500/30 bg-slate-800' : 'text-slate-300 hover:bg-slate-800/80'}`}
            title="Toggle Night Mode"
          >
            {isNightMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsLibraryOpen(true)}
            className="bg-slate-900/50 backdrop-blur-md border border-slate-800 text-slate-300 hover:text-white px-3 sm:px-4 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-medium flex items-center shadow-lg transition-all hover:bg-slate-800/80"
          >
            <Library className="w-4 h-4 mr-1 sm:mr-2" />
            Library
          </button>
        </div>
      </div>

      <main className="max-w-2xl mx-auto px-6 pt-28 pb-12 md:pt-32 md:pb-20 relative z-10 min-h-screen flex flex-col justify-center">
        
        {isOffline && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 bg-amber-500/10 border border-amber-500/20 text-amber-200 px-5 py-4 rounded-2xl flex items-center shadow-lg backdrop-blur-md"
          >
            <WifiOff className="w-5 h-5 mr-3 flex-shrink-0 text-amber-400" />
            <div>
              <p className="font-medium text-amber-300 text-sm">You are offline</p>
              <p className="text-xs text-amber-200/80 mt-0.5">You can still read stories in your Library, but creating new ones requires an internet connection.</p>
            </div>
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {!showStory ? (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, filter: "blur(4px)" }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="w-full"
            >
              <div className="text-center mb-10">
                <motion.div 
                  initial={{ rotate: -5, opacity: 0, scale: 0.8 }}
                  animate={{ rotate: 0, opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="mx-auto mb-6 w-40 h-40 rounded-2xl overflow-hidden shadow-[0_0_40px_rgba(32,33,74,0.5)] border border-indigo-400/10"
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                    <rect width="100" height="100" fill="#1e1b4b" />
                    <circle cx="50" cy="50" r="46" fill="none" stroke="#dcb76e" strokeWidth="1" />
                    
                    {/* Stars */}
                    <circle cx="36" cy="26" r="0.8" fill="#e2e8f0" />
                    <circle cx="62" cy="24" r="0.6" fill="#e2e8f0" />
                    <circle cx="74" cy="36" r="1" fill="#e2e8f0" />
                    <circle cx="26" cy="42" r="1.2" fill="#e2e8f0" />
                    <circle cx="82" cy="52" r="0.8" fill="#e2e8f0" />
                    <circle cx="30" cy="58" r="0.6" fill="#e2e8f0" />
                    <circle cx="68" cy="62" r="0.8" fill="#e2e8f0" />
                    
                    {/* Cloud */}
                    <g fill="#93c4fd">
                      <circle cx="36" cy="42" r="10" />
                      <circle cx="64" cy="42" r="10" />
                      <circle cx="50" cy="32" r="14" />
                      <circle cx="43" cy="44" r="11" />
                      <circle cx="57" cy="44" r="11" />
                      <rect x="34" y="38" width="32" height="16" rx="8" />
                    </g>
                    
                    {/* Face */}
                    <g fill="none" stroke="#1e1b4b" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M 43 41 Q 45 43 47 41" />
                      <path d="M 53 41 Q 55 43 57 41" />
                      <path d="M 48 46 Q 50 48 52 46" />
                    </g>
                    
                    {/* Bubbly PLOOF Text */}
                    <text x="50" y="74" fontSize="18" fontWeight="900" fontFamily="'Arial Rounded MT Bold', 'Nunito', 'Varela Round', system-ui, sans-serif" fill="#f8fafc" textAnchor="middle" letterSpacing="1.5">
                      PLOOF
                    </text>
                    {/* Tiny crescent near the 'O's */}
                    <path d="M 51.5 61 A 2 2 0 1 1 54 64 A 2.5 2.5 0 0 0 51.5 61 Z" fill="#f8fafc" />
                  </svg>
                </motion.div>
                <h1 className="sr-only">PLOOF</h1>
                <p className="text-slate-400 text-lg max-w-md mx-auto">
                  Craft a personalized, soothing bedtime story to help them drift off to sleep.
                </p>
              </div>

              <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800/80 rounded-3xl p-6 md:p-8 shadow-2xl">
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800/60">
                  <h2 className="text-lg font-medium text-white">Story Details</h2>
                  <button
                    type="button"
                    onClick={handleSurpriseMe}
                    className="text-xs flex items-center bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 px-3 py-1.5 rounded-full transition-colors border border-indigo-500/20 shadow-sm"
                  >
                    <Sparkles className="w-3 h-3 mr-1.5" />
                    Tired? Surprise Me
                  </button>
                </div>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="childName" className="block text-sm font-medium text-slate-400 mb-2 ml-1">
                        Who is this story for?
                      </label>
                      <input
                        type="text"
                        id="childName"
                        name="childName"
                        value={formData.childName}
                        onChange={handleChange}
                        placeholder="Child's name"
                        required
                        className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-5 py-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="favoriteAnimal" className="block text-sm font-medium text-slate-400 mb-2 ml-1">
                        Their favorite animal companion
                      </label>
                      <input
                        type="text"
                        id="favoriteAnimal"
                        name="favoriteAnimal"
                        value={formData.favoriteAnimal}
                        onChange={handleChange}
                        placeholder="e.g. A tiny brave hedgehog"
                        required
                        className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-5 py-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all"
                      />
                    </div>

                    <div>
                      <label htmlFor="setting" className="block text-sm font-medium text-slate-400 mb-2 ml-1">
                        Where does the journey take place? (Optional)
                      </label>
                      <input
                        type="text"
                        id="setting"
                        name="setting"
                        value={formData.setting}
                        onChange={handleChange}
                        placeholder="e.g. The Whispering Woods"
                        className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-5 py-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all"
                      />
                    </div>

                    <div>
                      <label htmlFor="magicalElement" className="block text-sm font-medium text-slate-400 mb-2 ml-1">
                        A magical element to find (Optional)
                      </label>
                      <input
                        type="text"
                        id="magicalElement"
                        name="magicalElement"
                        value={formData.magicalElement}
                        onChange={handleChange}
                        placeholder="e.g. A glowing moonstone"
                        className="w-full bg-slate-950/50 border border-slate-800 rounded-2xl px-5 py-4 text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-2 ml-1">
                        Story Length
                      </label>
                      <div className="grid grid-cols-3 gap-3">
                        {['short', 'medium', 'long'].map((length) => (
                          <button
                            key={length}
                            type="button"
                            onClick={() => setFormData(prev => ({ ...prev, storyLength: length }))}
                            className={`px-2 sm:px-4 py-3 rounded-2xl text-xs sm:text-sm font-medium capitalize transition-all ${
                              formData.storyLength === length 
                                ? 'bg-indigo-600 border border-transparent text-white' 
                                : 'bg-slate-950/50 border border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300'
                            }`}
                          >
                            {length}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <AnimatePresence>
                    {error && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0, marginTop: 0 }}
                        animate={{ opacity: 1, height: 'auto', marginTop: 24 }}
                        exit={{ opacity: 0, height: 0, marginTop: 0 }}
                        className="bg-red-500/10 border border-red-500/20 text-red-200 text-sm px-5 py-4 rounded-2xl flex items-start overflow-hidden"
                      >
                        <span className="mr-2">✨</span>
                        {error}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {!isSubscribed && generationsCount >= 3 ? (
                    <button
                      type="button"
                      onClick={() => {
                        setCheckoutStep('form');
                        setIsCheckoutOpen(true);
                      }}
                      className="w-full bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 hover:from-indigo-600 hover:via-purple-700 hover:to-pink-600 text-white font-semibold rounded-2xl px-6 py-4 flex items-center justify-center transition-all shadow-[0_0_30px_rgba(99,102,241,0.4)] hover:shadow-[0_0_40px_rgba(99,102,241,0.6)] group transform hover:-translate-y-0.5"
                    >
                      <Sparkles className="w-5 h-5 mr-3 animate-pulse text-white" />
                      Unlock Unlimited Bedtime Magic ($3.99/mo)
                    </button>
                  ) : (
                    <button
                      type="submit"
                      disabled={isGenerating || isOffline || !formData.childName || !formData.favoriteAnimal}
                      className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-medium rounded-2xl px-6 py-4 flex items-center justify-center transition-colors group"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-3 animate-spin text-indigo-300" />
                          Weaving the magic...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5 mr-3 group-hover:animate-pulse text-indigo-200" />
                          Generate Bedtime Story
                        </>
                      )}
                    </button>
                  )}
                </form>
              </div>


              {/* Demo Controls Section */}
              {window.location.hostname.includes('run.app') && (
                <div className="mt-8 border-t border-slate-800/40 pt-6 text-left">
                  <h3 className="text-xs font-semibold text-slate-400 mb-4 uppercase tracking-wider">Demo Sandbox Controls</h3>
                  <div className="flex flex-wrap gap-3">
                    <button onClick={() => saveGenerationsCount(0)} className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition-colors">Reset Free Limits</button>
                    <button onClick={() => saveSubscriptionStatus(!isSubscribed)} className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition-colors">Toggle Premium / Subscribe</button>
                    <button onClick={() => setIsCheckoutOpen(true)} className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition-colors">Open Checkout</button>
                  </div>
                </div>
              )}
              {!isSubscribed && (
                <>
                  {/* Features / Value Prop Section */}
              <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-slate-900/30 border border-slate-800/50 rounded-3xl p-6 text-center shadow-lg transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 mx-auto bg-indigo-500/10 rounded-2xl flex items-center justify-center mb-4">
                    <CloudMoon className="w-6 h-6 text-indigo-400" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-200 mb-2">Sleep-Optimized</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Our magical weavers start the story engaging, then smoothly transition into a slow, rhythmic cadence to guide them to sleep.
                  </p>
                </div>
                
                <div className="bg-slate-900/30 border border-slate-800/50 rounded-3xl p-6 text-center shadow-lg transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 mx-auto bg-amber-500/10 rounded-2xl flex items-center justify-center mb-4">
                    <Wand2 className="w-6 h-6 text-amber-400" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-200 mb-2">Infinite Adventures</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Say goodbye to reading the same book every night. Generate beautifully illustrated unique stories tailored to their current obsessions.
                  </p>
                </div>
                
                <div className="bg-slate-900/30 border border-slate-800/50 rounded-3xl p-6 text-center shadow-lg transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 mx-auto bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-4">
                    <Heart className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-200 mb-2">100% Kid-Safe AI</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Built with strict safety guardrails. No scary monsters, loud surprises, or dark twists. Just pure, comforting bedtime magic.
                  </p>
                </div>
              </div>

              {/* Social Proof / Testimonial */}
              <div className="mt-8 bg-slate-900/40 border border-slate-800/60 rounded-3xl p-8 relative overflow-hidden shadow-xl">
                <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
                   <Star className="w-32 h-32 text-white" />
                </div>
                <div className="relative z-10 flex flex-col md:flex-row items-center md:items-start gap-6 text-center md:text-left">
                  <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150" alt="Happy Parent" className="w-16 h-16 rounded-full border-2 border-indigo-500/30 object-cover flex-shrink-0 mx-auto md:mx-0" />
                  <div>
                    <div className="flex gap-1 mb-3 justify-center md:justify-start">
                      {[1,2,3,4,5].map(i => <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />)}
                    </div>
                    <p className="text-sm text-slate-300 italic mb-3 leading-relaxed">
                      "I used to spend $15+ per picture book and she'd get bored of them in a week. With Ploof, we make a new story every night about whatever she's excited about that day. The illustrations are breathtaking, and it puts her out in 10 minutes flat. Best $3.99 I've ever spent."
                    </p>
                    <p className="text-xs font-semibold text-slate-400">— Sarah M., Mom of two</p>
                  </div>
                </div>
              </div>

                </>
              )}

              {/* FAQ & Support Section */}
              <div className="mt-12 border-t border-slate-800/80 pt-10">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="bg-indigo-500/10 p-2 rounded-xl border border-indigo-500/20">
                    <MessageSquare className="w-5 h-5 text-indigo-400" />
                  </div>
                  <h2 className="text-lg font-medium text-white">Frequently Asked Questions & Support</h2>
                </div>

                <div className="space-y-4">
                  {[
                    {
                      q: "How does Ploof create these bedtime stories?",
                      a: "Ploof uses safe, state-of-the-art AI to weave personalized bedtime stories using your child's name, favorite companion, and chosen setting. The stories are crafted with a calming, rhythmic narrative structure specifically designed to help children naturally wind down."
                    },
                    {
                      q: "How much does Ploof cost?",
                      a: "Ploof offers 3 free stories so you can try out the magic! After that, you can subscribe to Ploof Premium for only $3.99/month. This helps us cover the magical energy and server computing required to weave these unique bedtime stories and beautiful custom illustrations."
                    },
                    {
                      q: "Are the stories always safe for kids?",
                      a: "Absolutely. Ploof is programmed with strict guidelines: stories are warm, gentle, and comforting. We completely avoid scary elements, loud surprises, monsters, or sudden plot twists that could wake a sleepy child up."
                    },
                    {
                      q: "Can I download or save my child's favorite tales?",
                      a: "Yes! Once a story is generated, you can click the Save button to store it in your Library. You can also click the Download button to download a text file (.md) or use the Share button to copy the story or text it to other family members!"
                    },
                    {
                      q: "What should I do if a story fails to generate or won't load?",
                      a: "While our magic is very reliable, occasional network hiccups can happen. If a story doesn't load or generates an error, simply try clicking 'Generate' again. If the issue persists, wait a few moments and try one more time as the magical weavers might just be a bit busy!"
                    }
                  ].map((item, idx) => {
                    const isOpen = activeFaqIndex === idx;
                    return (
                      <div 
                        key={idx} 
                        className="bg-slate-900/30 border border-slate-800/60 rounded-2xl overflow-hidden transition-all duration-300 hover:border-slate-800"
                      >
                        <button
                          type="button"
                          onClick={() => setActiveFaqIndex(isOpen ? null : idx)}
                          className="w-full text-left px-5 py-4 flex justify-between items-center text-slate-200 hover:text-white font-medium text-sm transition-colors focus:outline-none"
                        >
                          <span>{item.q}</span>
                          <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${isOpen ? 'rotate-180 text-indigo-400' : ''}`} />
                        </button>
                        
                        <div 
                          className={`px-5 transition-all duration-300 ease-in-out overflow-hidden ${
                            isOpen ? 'max-h-40 pb-4 opacity-100' : 'max-h-0 opacity-0'
                          }`}
                        >
                          <p className="text-xs text-slate-400 leading-relaxed">
                            {item.a}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="story"
              initial={{ opacity: 0, scale: 0.95, filter: "blur(4px)" }}
              animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="w-full"
            >
              <div className="flex justify-between items-center mb-8">
                <button 
                  onClick={handleReset}
                  className="group bg-slate-900/50 hover:bg-slate-800 border border-slate-700/50 hover:border-slate-600 text-xs sm:text-sm font-medium text-slate-300 hover:text-white px-3 sm:px-4 py-2 sm:py-2.5 rounded-full flex items-center transition-all shadow-sm"
                >
                  <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
                  Weave New Story
                </button>
                <div className="flex items-center space-x-2 md:space-x-4">
                  <button
                    onClick={handleShare}
                    className="p-2 text-slate-400 hover:text-white bg-slate-900/50 hover:bg-slate-800 border border-slate-800 rounded-full transition-all"
                    title="Share story"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={handleDownload}
                    className="p-2 text-slate-400 hover:text-white bg-slate-900/50 hover:bg-slate-800 border border-slate-800 rounded-full transition-all"
                    title="Download story"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  
                  <button
                    onClick={handleSave}
                    disabled={isSaved}
                    className={`text-sm font-medium px-4 py-2 rounded-full flex items-center transition-all ${
                      isSaved 
                        ? 'bg-indigo-900/30 text-indigo-300 border border-indigo-700/30 cursor-default' 
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                    }`}
                  >
                    {isSaved ? (
                      <>
                        <BookmarkCheck className="w-4 h-4 mr-2" />
                        Saved
                      </>
                    ) : (
                      <>
                        <Bookmark className="w-4 h-4 mr-2" />
                        Save
                      </>
                    )}
                  </button>
                </div>
              </div>
              
              <div className="bg-slate-900/40 backdrop-blur-sm border border-slate-800/60 rounded-3xl md:p-12 shadow-2xl relative overflow-hidden">
                {imageUrl && (
                  <div className="w-full h-48 md:h-64 border-b border-slate-800/60 overflow-hidden relative">
                    <img 
                      src={imageUrl} 
                      alt="Story illustration" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
                
                <div className="p-8 md:p-0 md:pt-8">
                  <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
                    <Star className="w-32 h-32 text-indigo-300" />
                  </div>
                  
                  <div className="prose prose-invert prose-slate prose-lg max-w-none prose-headings:font-medium prose-headings:tracking-tight prose-headings:text-indigo-100 prose-p:leading-relaxed prose-p:text-slate-300">
                    <Markdown>{story}</Markdown>
                  </div>

                  {/* Continuation Section */}
                  <div className="mt-12 pt-8 border-t border-slate-800/60 flex flex-col items-center text-center space-y-4">
                    <div className="max-w-md">
                      <h4 className="text-sm font-medium text-slate-200 flex items-center justify-center space-x-1.5">
                        <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                        <span>The story doesn't have to end here!</span>
                      </h4>
                      <p className="text-xs text-slate-400 mt-1">
                        If <span className="text-indigo-300 font-semibold">{formData.childName}</span> is still awake and wants to hear what happens next, we can weave a brand new chapter continuing this exact adventure.
                      </p>
                    </div>

                    <button
                      onClick={handleContinueStory}
                      disabled={isContinuing || isGenerating || isOffline}
                      className="relative overflow-hidden group bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-medium px-6 py-3.5 rounded-2xl flex items-center justify-center transition-all shadow-[0_0_20px_rgba(99,102,241,0.2)] hover:shadow-[0_0_35px_rgba(99,102,241,0.4)] disabled:shadow-none"
                    >
                      {isContinuing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2.5 animate-spin text-indigo-200" />
                          Weaving Chapter {chapterCount + 1}...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2.5 group-hover:animate-pulse text-indigo-200" />
                          Weave Chapter {chapterCount + 1} 🌙
                        </>
                      )}
                    </button>
                    {continueError && (
                      <p className="text-xs text-red-400 mt-2">{continueError}</p>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <AnimatePresence>
        {isLibraryOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40"
              onClick={() => setIsLibraryOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-slate-900 border-l border-slate-800 z-50 overflow-y-auto flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-slate-800 flex justify-between items-center sticky top-0 bg-slate-900/95 backdrop-blur z-10">
                <h2 className="text-xl font-medium text-white flex items-center">
                  <Library className="w-5 h-5 mr-3 text-indigo-400" />
                  Library
                </h2>
                <button
                  onClick={() => setIsLibraryOpen(false)}
                  className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="p-6 flex-1">
                {savedStories.length === 0 ? (
                  <div className="text-center text-slate-500 mt-10">
                    <BookOpen className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p>No saved stories yet.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {savedStories.map(s => (
                      <div 
                        key={s.id} 
                        className="bg-slate-950/50 border border-slate-800/80 rounded-2xl p-5 hover:border-indigo-500/50 transition-colors cursor-pointer group flex justify-between items-start"
                        onClick={() => {
                          setStory(s.content);
                          setImageUrl(s.imageUrl || '');
                          setShowStory(true);
                          setIsSaved(true);
                          setIsLibraryOpen(false);
                        }}
                      >
                        <div>
                          <h3 className="text-white font-medium mb-2 group-hover:text-indigo-300 transition-colors">{s.title}</h3>
                          <p className="text-xs text-slate-500">
                            {new Date(s.date).toLocaleDateString(undefined, { 
                              month: 'short', day: 'numeric', year: 'numeric' 
                            })}
                          </p>
                        </div>
                        <button
                          onClick={(e) => handleDeleteSaved(s.id, e)}
                          className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-400/10 rounded-full transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                          title="Delete story"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Checkout Modal */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 pointer-events-auto"
              onClick={() => {
                if (checkoutStep !== 'loading') {
                  setIsCheckoutOpen(false);
                }
              }}
            >
              {/* Modal Card */}
              <motion.div
                initial={{ scale: 0.95, y: 20, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.95, y: 20, opacity: 0 }}
                transition={{ type: "spring", duration: 0.5 }}
                className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(99,102,241,0.2)] relative z-50 flex flex-col"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Header with beautiful cloud or stars */}
                <div className="p-6 text-center border-b border-slate-800 relative bg-gradient-to-b from-indigo-950/40 to-transparent">
                  {checkoutStep !== 'loading' && (
                    <button
                      onClick={() => setIsCheckoutOpen(false)}
                      className="absolute top-4 right-4 p-2 text-slate-500 hover:text-white hover:bg-slate-850 rounded-full transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                  <div className="mx-auto w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center mb-3 border border-indigo-500/20">
                    <Sparkles className="w-6 h-6 text-indigo-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">Ploof Bedtime Bedrock</h3>
                  <p className="text-xs text-slate-400">Unlock infinite magic for your little ones</p>
                </div>

                <AnimatePresence mode="wait">
                  {checkoutStep === 'form' && (
                    <motion.div
                      key="checkout-form"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className="p-6 space-y-6"
                    >
                      {/* Price info card */}
                      <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-2xl p-4 flex justify-between items-center">
                        <div>
                          <p className="text-sm font-semibold text-white">Ploof Bedtime Unlimited</p>
                          <p className="text-[11px] text-indigo-300">Unlimited personalized bedtime stories & images</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-white">$3.99</p>
                          <p className="text-[10px] text-slate-400">per month</p>
                        </div>
                      </div>

                      {/* Perks */}
                      <div className="space-y-2 text-xs text-slate-300">
                        <div className="flex items-center">
                          <Star className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400/20 mr-2 shrink-0" />
                          <span>Generate as many customized stories as you want</span>
                        </div>
                        <div className="flex items-center">
                          <Star className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400/20 mr-2 shrink-0" />
                          <span>Delightful dream-like illustrations for every book</span>
                        </div>
                        <div className="flex items-center">
                          <Star className="w-3.5 h-3.5 text-indigo-400 fill-indigo-400/20 mr-2 shrink-0" />
                          <span>Adjust story length (short, medium, long)</span>
                        </div>
                      </div>

                      {/* Mockup inputs or Google Login */}
                      {!user ? (
                        <div className="flex flex-col items-center justify-center space-y-4 pt-4 border-t border-slate-800">
                          <p className="text-sm font-medium text-slate-300">
                            Create an account to subscribe
                          </p>
                          <button
                            onClick={async () => {
                              try {
                                await signInWithPopup(auth, googleProvider);
                              } catch (error) {
                                console.error(error);
                              }
                            }}
                            className="w-full bg-white hover:bg-slate-50 text-slate-900 font-medium rounded-xl px-4 py-3 text-sm flex items-center justify-center transition-colors shadow-sm"
                          >
                            <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                            </svg>
                            Continue with Google
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4 text-left border-t border-slate-800 pt-4">
                          <div className="flex justify-between items-center bg-indigo-500/10 rounded-xl px-4 py-3 mb-4">
                            <div className="flex items-center">
                              {user.photoURL && <img src={user.photoURL} alt="Profile" className="w-6 h-6 rounded-full mr-3" />}
                              <span className="text-xs text-indigo-200">{user.email}</span>
                            </div>
                            <button 
                              type="button" 
                              onClick={() => signOut(auth)}
                              className="text-[10px] text-indigo-400 hover:text-indigo-300"
                            >
                              Sign out
                            </button>
                          </div>
                          
                          <button
                            onClick={async () => {
                              setCheckoutStep('loading');
                              try {
                                const response = await fetch('/api/create-checkout-session', {
                                  method: 'POST',
                                  headers: {
                                    'Content-Type': 'application/json'
                                  },
                                  body: JSON.stringify({ userId: user.uid, email: user.email })
                                });
                                const session = await response.json();
                                if (session.url) {
                                  window.location.href = session.url;
                                } else if (session.id) {
                                  const stripe = await loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);
                                  const result = await (stripe as any)?.redirectToCheckout({ sessionId: session.id });
                                  if (result?.error) {
                                    throw new Error(result.error.message);
                                  }
                                } else {
                                  throw new Error(session.error || 'Failed to initialize checkout session');
                                }
                              } catch (err: any) {
                                console.error('Checkout error:', err);
                                alert(err.message || 'Payment system error. Please check your Stripe configuration.');
                                setCheckoutStep('form');
                              }
                            }}
                            className="w-full mt-2 bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 hover:from-indigo-600 hover:via-purple-700 hover:to-pink-600 text-white font-medium rounded-xl py-3 text-xs transition-all flex items-center justify-center shadow-lg"
                          >
                            ✨ Start Bedtime Magic — $3.99/mo
                          </button>
                          <p className="text-[10px] text-center text-slate-500">
                            Secure payments via Stripe. Cancel anytime in one click.
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}

                  {checkoutStep === 'loading' && (
                    <motion.div
                      key="checkout-loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="p-12 flex flex-col items-center justify-center text-center space-y-4"
                    >
                      <Loader2 className="w-10 h-10 animate-spin text-indigo-400" />
                      <div>
                        <p className="text-sm font-semibold text-white">Weaving Bedtime Magic...</p>
                        <p className="text-xs text-slate-500">Securing your lifetime subscription tunnel</p>
                      </div>
                    </motion.div>
                  )}

                  {checkoutStep === 'success' && (
                    <motion.div
                      key="checkout-success"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0 }}
                      className="p-8 text-center space-y-6 animate-none"
                    >
                      <div className="mx-auto w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                        <Check className="w-8 h-8 text-emerald-400" />
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-lg font-bold text-white">Subscription Active! 🌟</h4>
                        <p className="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto">
                          Welcome to Ploof Bedtime Unlimited. Your children's names and dreams are now ready for endless bedtime adventures.
                        </p>
                      </div>
                      <button
                        onClick={() => setIsCheckoutOpen(false)}
                        className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium rounded-xl py-3 text-xs transition-colors"
                      >
                        Let's Create a Story! ✨
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <footer className="w-full py-8 text-center text-xs text-slate-500 relative z-10 flex flex-col items-center justify-center space-y-2 mt-auto">
        <p>© 2026 Ploof Bedtime Stories.</p>
        <div className="flex space-x-4">
          <button onClick={() => setView('privacy')} className="hover:text-slate-300 transition-colors">Privacy Policy</button>
          <button onClick={() => setView('tos')} className="hover:text-slate-300 transition-colors">Terms of Service</button>
        </div>
      </footer>
    </div>
  );
}
