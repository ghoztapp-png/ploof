const fs = require('fs');
let code = fs.readFileSync('vite.config.ts', 'utf8');
const pwaTarget = `registerType: 'autoUpdate',`;
const pwaReplace = `registerType: 'autoUpdate',
        injectRegister: 'auto',
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg}']
        },`;
if (!code.includes('injectRegister:')) {
  code = code.replace(pwaTarget, pwaReplace);
  fs.writeFileSync('vite.config.ts', code);
}
