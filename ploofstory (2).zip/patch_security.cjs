const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

if (!code.includes("firebase-admin/auth")) {
  code = code.replace('import Stripe from \'stripe\';', `import Stripe from 'stripe';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import config from './firebase-applet-config.json' with { type: 'json' };`);
}

if (!code.includes("const adminApp = initializeApp(")) {
  code = code.replace('const ai = new GoogleGenAI', `const adminApp = initializeApp({ projectId: config.projectId });
const adminAuth = getAuth(adminApp);

const ai = new GoogleGenAI`);
}

if (!code.includes("async function verifyUser")) {
  const helpers = `
async function verifyUser(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) throw new Error('Unauthorized');
  const token = authHeader.split('Bearer ')[1];
  return { decodedToken: await adminAuth.verifyIdToken(token), idToken: token };
}

async function checkSubscriptionAndLimits(decodedToken, idToken) {
  const stripe = getStripe();
  if (decodedToken.email) {
    const customers = await stripe.customers.list({ email: decodedToken.email });
    for (const customer of customers.data) {
      const subs = await stripe.subscriptions.list({ customer: customer.id, status: 'active' });
      if (subs.data.length > 0) return true; // Subscribed!
    }
  }

  const url = \`https://firestore.googleapis.com/v1/projects/\${config.projectId}/databases/\${config.firestoreDatabaseId}/documents/users/\${decodedToken.uid}\`;
  let count = 0;
  try {
    const response = await fetch(url, { headers: { Authorization: \`Bearer \${idToken}\` } });
    if (response.ok) {
      const data = await response.json();
      if (data.fields && data.fields.generationsCount) {
        count = parseInt(data.fields.generationsCount.integerValue || '0', 10);
      }
    }
  } catch(e) {
    console.error("Error reading usage count:", e);
  }

  if (count >= 3) {
    throw new Error('LimitReached');
  }
  
  return { isFree: true, currentCount: count };
}

async function incrementUsage(decodedToken, idToken, currentCount) {
  const url = \`https://firestore.googleapis.com/v1/projects/\${config.projectId}/databases/\${config.firestoreDatabaseId}/documents/users/\${decodedToken.uid}?updateMask.fieldPaths=generationsCount\`;
  const body = { fields: { generationsCount: { integerValue: currentCount + 1 } } };
  try {
    await fetch(url, {
      method: 'PATCH',
      headers: { Authorization: \`Bearer \${idToken}\`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } catch(e) {
    console.error("Error incrementing usage:", e);
  }
}
`;
  code = code.replace('async function startServer() {', helpers + '\nasync function startServer() {');
}

code = code.replace('app.post("/api/generate", async (req, res) => {', `app.post("/api/generate", async (req, res) => {
    let userAuth, subStatus;
    try {
      userAuth = await verifyUser(req);
      subStatus = await checkSubscriptionAndLimits(userAuth.decodedToken, userAuth.idToken);
    } catch (e) {
      if (e.message === 'LimitReached') return res.status(403).json({ error: "Free limit reached. Please subscribe." });
      return res.status(401).json({ error: "Unauthorized" });
    }`);

code = code.replace('res.json({ story: response.text });', `res.json({ story: response.text });
      if (subStatus && subStatus.isFree) {
        await incrementUsage(userAuth.decodedToken, userAuth.idToken, subStatus.currentCount);
      }`);

code = code.replace('app.post("/api/continue", async (req, res) => {', `app.post("/api/continue", async (req, res) => {
    let userAuth, subStatus;
    try {
      userAuth = await verifyUser(req);
      subStatus = await checkSubscriptionAndLimits(userAuth.decodedToken, userAuth.idToken);
    } catch (e) {
      if (e.message === 'LimitReached') return res.status(403).json({ error: "Free limit reached. Please subscribe." });
      return res.status(401).json({ error: "Unauthorized" });
    }`);

fs.writeFileSync('server.ts', code);
