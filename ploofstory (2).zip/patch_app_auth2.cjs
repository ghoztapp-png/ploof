const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace(/fetch\('\/api\/generate',\s*\{\s*headers:\s*\{[\s\S]*?method:\s*'POST',\s*headers:\s*\{\s*'Content-Type':\s*'application\/json',\s*\},/g, `fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(auth.currentUser ? { 'Authorization': \`Bearer \${await auth.currentUser.getIdToken()}\` } : {})
        },`);

code = code.replace(/fetch\('\/api\/continue',\s*\{\s*headers:\s*\{[\s\S]*?method:\s*'POST',\s*headers:\s*\{\s*'Content-Type':\s*'application\/json',\s*\},/g, `fetch('/api/continue', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(auth.currentUser ? { 'Authorization': \`Bearer \${await auth.currentUser.getIdToken()}\` } : {})
        },`);

fs.writeFileSync('src/App.tsx', code);
