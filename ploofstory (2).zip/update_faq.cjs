const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

// Update FAQ string
code = code.replace(
  "If the issue persists, please use the Report an Issue form below to let us know instantly! We monitor all reports to keep Ploof running smoothly.",
  "If the issue persists, wait a few moments and try one more time as the magical weavers might just be a bit busy!"
);

// Remove the form
const formStart = code.indexOf('{/* Report an Issue Form */}');
const formEnd = code.indexOf('{/* Demo Controls Section */}');
if (formStart > -1 && formEnd > -1) {
  code = code.substring(0, formStart) + code.substring(formEnd);
}

fs.writeFileSync('src/App.tsx', code);
