const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `  const toggleNightMode = () => {`;
const replace = `  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowInstallBtn(false);
    }
    setDeferredPrompt(null);
  };

  const toggleNightMode = () => {`;

code = code.replace(target, replace);
fs.writeFileSync('src/App.tsx', code);
