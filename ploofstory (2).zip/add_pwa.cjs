const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

// add deferred prompt state
const stateTarget = `  // Settings
  const [isNightMode, setIsNightMode] = useState(false);`;

const stateReplacement = `  // Settings
  const [isNightMode, setIsNightMode] = useState(false);
  
  // PWA Install State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBtn, setShowInstallBtn] = useState(false);`;

code = code.replace(stateTarget, stateReplacement);

// add beforeinstallprompt listener
const effectTarget = `  useEffect(() => {
    const handleOnline = () => setIsOffline(false);`;

const effectReplacement = `  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBtn(true);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    const handleOnline = () => setIsOffline(false);`;

code = code.replace(effectTarget, effectReplacement);

const cleanupTarget = `    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribeAuth();
    };
  }, []);`;

const cleanupReplacement = `    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubscribeAuth();
    };
  }, []);`;

code = code.replace(cleanupTarget, cleanupReplacement);

fs.writeFileSync('src/App.tsx', code);
