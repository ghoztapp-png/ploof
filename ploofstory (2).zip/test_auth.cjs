const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const config = require('./firebase-applet-config.json');

try {
  const app = initializeApp({
    projectId: config.projectId,
  });
  console.log("App initialized");
  // Just testing if auth object is available
  const auth = getAuth(app);
  console.log("Auth available");
} catch (e) {
  console.error("Failed", e);
}
