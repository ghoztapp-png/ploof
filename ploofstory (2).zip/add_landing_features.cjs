const fs = require('fs');

let code = fs.readFileSync('src/App.tsx', 'utf8');

const insertContent = `
              {/* Features / Value Prop Section */}
              <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-slate-900/30 border border-slate-800/50 rounded-3xl p-6 text-center shadow-lg transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 mx-auto bg-indigo-500/10 rounded-2xl flex items-center justify-center mb-4">
                    <Moon className="w-6 h-6 text-indigo-400" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-200 mb-2">Sleep-Optimized</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Our magical weavers start the story engaging, then smoothly transition into a slow, rhythmic cadence to guide them to sleep.
                  </p>
                </div>
                
                <div className="bg-slate-900/30 border border-slate-800/50 rounded-3xl p-6 text-center shadow-lg transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 mx-auto bg-amber-500/10 rounded-2xl flex items-center justify-center mb-4">
                    <BookOpen className="w-6 h-6 text-amber-400" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-200 mb-2">Infinite Adventures</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Say goodbye to reading the same book every night. Generate beautifully illustrated unique stories tailored to their current obsessions.
                  </p>
                </div>
                
                <div className="bg-slate-900/30 border border-slate-800/50 rounded-3xl p-6 text-center shadow-lg transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 mx-auto bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-4">
                    <Star className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h3 className="text-sm font-medium text-slate-200 mb-2">100% Kid-Safe AI</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Built with strict safety guardrails. No scary monsters, loud surprises, or dark twists. Just pure, comforting bedtime magic.
                  </p>
                </div>
              </div>

              {/* Social Proof / Testimonial */}
              <div className="mt-8 bg-slate-900/40 border border-slate-800/60 rounded-3xl p-8 relative overflow-hidden shadow-xl">
                <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
                   <Star className="w-32 h-32 text-white" />
                </div>
                <div className="relative z-10 flex flex-col md:flex-row items-center md:items-start gap-6 text-center md:text-left">
                  <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150" alt="Happy Parent" className="w-16 h-16 rounded-full border-2 border-indigo-500/30 object-cover flex-shrink-0 mx-auto md:mx-0" />
                  <div>
                    <div className="flex gap-1 mb-3 justify-center md:justify-start">
                      {[1,2,3,4,5].map(i => <Star key={i} className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />)}
                    </div>
                    <p className="text-sm text-slate-300 italic mb-3 leading-relaxed">
                      "I used to spend $15+ per picture book and she'd get bored of them in a week. With Ploof, we make a new story every night about whatever she's excited about that day. The illustrations are breathtaking, and it puts her out in 10 minutes flat. Best $3.99 I've ever spent."
                    </p>
                    <p className="text-xs font-semibold text-slate-400">— Sarah M., Mom of two</p>
                  </div>
                </div>
              </div>
`;

code = code.replace(
  '              {/* FAQ & Support Section */}',
  insertContent + '\n              {/* FAQ & Support Section */}'
);

fs.writeFileSync('src/App.tsx', code);
