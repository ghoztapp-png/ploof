const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const config = require('./firebase-applet-config.json');

try {
  const app = initializeApp({ projectId: config.projectId });
  const auth = getAuth(app);
  auth.createCustomToken('test-uid', { isSubscribed: true })
    .then(token => console.log("Success! Token:", token.substring(0, 20) + "..."))
    .catch(e => console.error("Token Error:", e.message));
} catch (e) {
  console.error("Init Failed", e);
}
