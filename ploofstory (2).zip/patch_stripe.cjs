const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes("import { loadStripe } from '@stripe/stripe-js';")) {
  code = code.replace("import React, { useState, useEffect } from 'react';", "import React, { useState, useEffect } from 'react';\nimport { loadStripe } from '@stripe/stripe-js';");
}

const targetForm = `                        <form 
                          onSubmit={(e) => {
                            e.preventDefault();
                            setCheckoutStep('loading');
                            setTimeout(() => {
                              setCheckoutStep('success');
                              saveSubscriptionStatus(true);
                            }, 1800);
                          }} 
                          className="space-y-4 text-left border-t border-slate-800 pt-4"
                        >
                          <div className="flex justify-between items-center bg-indigo-500/10 rounded-xl px-4 py-3 mb-4">
                            <div className="flex items-center">
                              {user.photoURL && <img src={user.photoURL} alt="Profile" className="w-6 h-6 rounded-full mr-3" />}
                              <span className="text-xs text-indigo-200">{user.email}</span>
                            </div>
                            <button 
                              type="button" 
                              onClick={() => signOut(auth)}
                              className="text-[10px] text-indigo-400 hover:text-indigo-300"
                            >
                              Sign out
                            </button>
                          </div>
                          <div>
                            <label className="block text-[11px] font-medium text-slate-400 mb-1">
                              Card Information
                            </label>
                            <div className="relative">
                              <input
                                type="text"
                                required
                                placeholder="4242  4242  4242  4242"
                                value={checkoutCard}
                                onChange={(e) => {
                                  const val = e.target.value.replace(/\\s+/g, '').replace(/[^0-9]/gi, '');
                                  const matches = val.match(/\\d{4,16}/g);
                                  const match = (matches && matches[0]) || '';
                                  const parts = [];
                                  for (let i = 0, len = match.length; i < len; i += 4) {
                                    parts.push(match.substring(i, i + 4));
                                  }
                                  if (parts.length > 0) {
                                    setCheckoutCard(parts.join('  '));
                                  } else {
                                    setCheckoutCard(val);
                                  }
                                }}
                                maxLength={22}
                                className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all font-mono"
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[11px] font-medium text-slate-400 mb-1">
                                Expiry
                              </label>
                              <input
                                type="text"
                                required
                                placeholder="MM / YY"
                                value={checkoutExpiry}
                                onChange={(e) => {
                                  let val = e.target.value.replace(/[^0-9]/g, '');
                                  if (val.length > 2) {
                                    val = val.substring(0, 2) + ' / ' + val.substring(2, 4);
                                  }
                                  setCheckoutExpiry(val);
                                }}
                                maxLength={7}
                                className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-medium text-slate-400 mb-1">
                                CVC
                              </label>
                              <input
                                type="text"
                                required
                                placeholder="123"
                                value={checkoutCvc}
                                onChange={(e) => setCheckoutCvc(e.target.value.replace(/[^0-9]/g, '').substring(0, 4))}
                                maxLength={4}
                                className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all font-mono"
                              />
                            </div>
                          </div>
                          <button
                            type="submit"
                            className="w-full mt-2 bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 hover:from-indigo-600 hover:via-purple-700 hover:to-pink-600 text-white font-medium rounded-xl py-3 text-xs transition-all flex items-center justify-center shadow-lg"
                          >
                            ✨ Start Bedtime Magic — $3.99/mo
                          </button>
                          <p className="text-[10px] text-center text-slate-500">
                            Secure payments. Cancel anytime in one click.
                          </p>
                        </form>`;

const replaceForm = `                        <div className="space-y-4 text-left border-t border-slate-800 pt-4">
                          <div className="flex justify-between items-center bg-indigo-500/10 rounded-xl px-4 py-3 mb-4">
                            <div className="flex items-center">
                              {user.photoURL && <img src={user.photoURL} alt="Profile" className="w-6 h-6 rounded-full mr-3" />}
                              <span className="text-xs text-indigo-200">{user.email}</span>
                            </div>
                            <button 
                              type="button" 
                              onClick={() => signOut(auth)}
                              className="text-[10px] text-indigo-400 hover:text-indigo-300"
                            >
                              Sign out
                            </button>
                          </div>
                          
                          <button
                            onClick={async () => {
                              setCheckoutStep('loading');
                              try {
                                const response = await fetch('/api/create-checkout-session', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ userId: user.uid, email: user.email })
                                });
                                const session = await response.json();
                                if (session.url) {
                                  const stripe = await loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);
                                  await stripe?.redirectToCheckout({ sessionId: session.id });
                                } else {
                                  throw new Error('No checkout URL');
                                }
                              } catch (err) {
                                console.error('Checkout error:', err);
                                setCheckoutStep('form');
                              }
                            }}
                            className="w-full mt-2 bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 hover:from-indigo-600 hover:via-purple-700 hover:to-pink-600 text-white font-medium rounded-xl py-3 text-xs transition-all flex items-center justify-center shadow-lg"
                          >
                            ✨ Start Bedtime Magic — $3.99/mo
                          </button>
                          <p className="text-[10px] text-center text-slate-500">
                            Secure payments via Stripe. Cancel anytime in one click.
                          </p>
                        </div>`;

code = code.replace(targetForm, replaceForm);
fs.writeFileSync('src/App.tsx', code);
