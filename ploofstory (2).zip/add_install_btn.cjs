const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `        {/* Right Buttons */}
        <div className="flex items-center space-x-3 pointer-events-auto">`;

const replace = `        {/* Right Buttons */}
        <div className="flex items-center space-x-3 pointer-events-auto">
          {showInstallBtn && (
            <button
              onClick={handleInstallClick}
              className="bg-indigo-600/20 backdrop-blur-md border border-indigo-500/40 text-indigo-300 hover:text-white hover:bg-indigo-600/40 px-4 py-2.5 rounded-full text-sm font-medium flex items-center shadow-lg transition-all"
            >
              <Download className="w-4 h-4 mr-2" />
              Install App
            </button>
          )}`;

code = code.replace(target, replace);
fs.writeFileSync('src/App.tsx', code);
