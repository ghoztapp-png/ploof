const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `                {/* Demo Controls Section */}
                <div className="mt-8 border-t border-slate-800/40 pt-6 text-left">`;

const replacement = `                {/* Demo Controls Section */}
                {import.meta.env.DEV && (
                <div className="mt-8 border-t border-slate-800/40 pt-6 text-left">`;

code = code.replace(target, replacement);

const targetEnd = `                  </div>
                </div>
              </div>

              {!isSubscribed && (`;

const replacementEnd = `                  </div>
                </div>
                )}
              </div>

              {!isSubscribed && (`;

code = code.replace(targetEnd, replacementEnd);
fs.writeFileSync('src/App.tsx', code);
