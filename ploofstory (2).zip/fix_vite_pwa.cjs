const fs = require('fs');
let code = fs.readFileSync('vite.config.ts', 'utf8');
code = code.replace(/\/icon-192\.svg/g, '/icon-192.png');
code = code.replace(/\/icon-512\.svg/g, '/icon-512.png');
code = code.replace(/image\/svg\+xml/g, 'image/png');
fs.writeFileSync('vite.config.ts', code);
