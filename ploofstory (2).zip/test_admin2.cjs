const { initializeApp } = require('firebase-admin/app');
const { getFirestore } = require('firebase-admin/firestore');
const config = require('./firebase-applet-config.json');

try {
  const app = initializeApp({
    projectId: config.projectId,
  });
  
  const db = getFirestore(app, config.firestoreDatabaseId);
  db.collection('test').doc('test').get()
    .then(doc => console.log("Success read:", doc.exists))
    .catch(e => console.error("Firestore Error:", e));

} catch (e) {
  console.error("Init Failed", e);
}
