const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetApp = `  const PORT = 3000;

  app.use(express.json());`;

const replaceApp = `  const PORT = 3000;

  // Stripe webhook must be placed before express.json() so it can read the raw body
  app.post('/api/stripe-webhook', express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!endpointSecret) {
      console.warn("STRIPE_WEBHOOK_SECRET is not configured");
      return res.status(400).send("Webhook secret not configured");
    }

    try {
      const stripe = getStripe();
      const event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);

      if (event.type === 'checkout.session.completed') {
        const session = event.data.object;
        const userId = session.client_reference_id;
        
        console.log(\`[Stripe Webhook] Checkout session completed for user: \${userId}\`);
        
        // TODO: Update user subscription status in database securely via Firebase Admin SDK
        // Example:
        // await admin.firestore().collection('users').doc(userId).update({ isSubscribed: true });
      }

      res.json({ received: true });
    } catch (err) {
      console.error(\`Webhook Error: \${err.message}\`);
      res.status(400).send(\`Webhook Error: \${err.message}\`);
    }
  });

  app.use(express.json());`;

code = code.replace(targetApp, replaceApp);
fs.writeFileSync('server.ts', code);
