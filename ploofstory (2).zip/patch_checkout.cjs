const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetUseEffect = `  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {`;
const replaceUseEffect = `  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');
    const checkoutCanceled = urlParams.get('checkout_canceled');

    if (sessionId) {
      setCheckoutStep('loading');
      setIsCheckoutOpen(true);
      fetch('/api/verify-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          saveSubscriptionStatus(true);
          setCheckoutStep('success');
        } else {
          setCheckoutStep('form');
        }
        window.history.replaceState({}, document.title, window.location.pathname);
      })
      .catch(err => {
        console.error(err);
        setCheckoutStep('form');
      });
    }

    if (checkoutCanceled) {
      setIsCheckoutOpen(true);
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    const handleBeforeInstallPrompt = (e: Event) => {`;

code = code.replace(targetUseEffect, replaceUseEffect);
fs.writeFileSync('src/App.tsx', code);
