const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const target = `              {!isSubscribed && (`;
const replace = `              {/* Demo Controls Section */}
              {window.location.hostname.includes('run.app') && (
                <div className="mt-8 border-t border-slate-800/40 pt-6 text-left">
                  <h3 className="text-xs font-semibold text-slate-400 mb-4 uppercase tracking-wider">Demo Sandbox Controls</h3>
                  <div className="flex flex-wrap gap-3">
                    <button onClick={() => saveGenerationsCount(0)} className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition-colors">Reset Free Limits</button>
                    <button onClick={() => saveSubscriptionStatus(!isSubscribed)} className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition-colors">Toggle Premium / Subscribe</button>
                    <button onClick={() => setIsCheckoutOpen(true)} className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs transition-colors">Open Checkout</button>
                  </div>
                </div>
              )}
              {!isSubscribed && (`;

code = code.replace(target, replace);
fs.writeFileSync('src/App.tsx', code);
