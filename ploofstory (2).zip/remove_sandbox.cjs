const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const startIdx = code.indexOf('{/* Demo Controls Section */}');
const endIdx = code.indexOf(')}', startIdx) + 2; // to include ')}'
if (startIdx !== -1 && endIdx !== -1) {
  const block = code.substring(startIdx, endIdx);
  code = code.replace(block, '');
  fs.writeFileSync('src/App.tsx', code);
}
