const config = require('./firebase-applet-config.json');

async function test() {
  // We need an ID token, which we don't have.
  console.log("REST API needs ID token. I'll just write the code for it.");
}
test();
