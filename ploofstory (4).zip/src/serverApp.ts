import express from "express";
import { GoogleGenAI } from "@google/genai";
import Stripe from 'stripe';
import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import config from '../firebase-applet-config.json' with { type: 'json' };

const adminApp = getApps().length === 0 ? initializeApp({ projectId: config.projectId }) : getApps()[0];
const adminAuth = getAuth(adminApp);

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
let stripeClient: Stripe | null = null;

function getStripe(): Stripe {
  if (!stripeClient) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) {
      throw new Error('STRIPE_SECRET_KEY environment variable is required');
    }
    stripeClient = new Stripe(key);
  }
  return stripeClient;
}

async function verifyUser(req: express.Request) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return null; // Guest user is completely fine
  }
  if (!authHeader.startsWith('Bearer ')) throw new Error('Unauthorized');
  const token = authHeader.split('Bearer ')[1];
  return { decodedToken: await adminAuth.verifyIdToken(token), idToken: token };
}

async function checkSubscriptionAndLimits(userAuth: { decodedToken: any, idToken: string } | null) {
  if (!userAuth) {
    // Guest user - limits are checked client-side via localStorage, not active subscription
    return { isFree: true, currentCount: 0, isGuest: true };
  }
  const { decodedToken, idToken } = userAuth;
  const stripe = getStripe();
  if (decodedToken.email) {
    const customers = await stripe.customers.list({ email: decodedToken.email });
    for (const customer of customers.data) {
      const subs = await stripe.subscriptions.list({ customer: customer.id, status: 'active' });
      if (subs.data.length > 0) return true; // Subscribed!
    }
  }

  const url = `https://firestore.googleapis.com/v1/projects/${config.projectId}/databases/${config.firestoreDatabaseId}/documents/users/${decodedToken.uid}`;
  let count = 0;
  try {
    const response = await fetch(url, { headers: { Authorization: `Bearer ${idToken}` } });
    if (response.ok) {
      const data = await response.json();
      if (data.fields && data.fields.generationsCount) {
        count = parseInt(data.fields.generationsCount.integerValue || '0', 10);
      }
    }
  } catch(e) {
    console.error("Error reading usage count:", e);
  }

  if (count >= 3) {
    throw new Error('LimitReached');
  }
  
  return { isFree: true, currentCount: count, isGuest: false };
}

async function incrementUsage(userAuth: { decodedToken: any, idToken: string } | null, currentCount: number) {
  if (!userAuth) return; // Guest
  const { decodedToken, idToken } = userAuth;
  const url = `https://firestore.googleapis.com/v1/projects/${config.projectId}/databases/${config.firestoreDatabaseId}/documents/users/${decodedToken.uid}?updateMask.fieldPaths=generationsCount`;
  const body = { fields: { generationsCount: { integerValue: currentCount + 1 } } };
  try {
    await fetch(url, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${idToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } catch(e) {
    console.error("Error incrementing usage:", e);
  }
}

async function sendWebhookNotification(type: 'generation_failed' | 'user_reported', details: any) {
  const webhookUrl = process.env.NOTIFICATION_WEBHOOK_URL;
  if (!webhookUrl) {
    console.log(`[Notification Bypass] No NOTIFICATION_WEBHOOK_URL configured. Details:`, details);
    return;
  }

  try {
    let content = "";
    if (type === 'generation_failed') {
      content = `⚠️ **PLOOF Story Generation Failed!**\n- **Child's Name:** ${details.childName || 'N/A'}\n- **Favorite Animal:** ${details.favoriteAnimal || 'N/A'}\n- **Error:** \`${details.error}\``;
    } else {
      content = `📨 **PLOOF User Issue Reported!**\n- **Category:** ${details.category}\n- **Message:** ${details.message}\n- **Context:** ${details.childName ? `For child "${details.childName}" (${details.favoriteAnimal})` : 'N/A'}`;
    }

    const isDiscord = webhookUrl.includes('discord.com');
    const body = isDiscord ? { content } : { text: content };

    await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    console.log(`[Notification Sent] Webhook alert successful.`);
  } catch (err) {
    console.error("Failed to send webhook notification:", err);
  }
}

export const app = express();

// Stripe webhook must be placed before express.json() so it can read the raw body
app.post('/api/stripe-webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'] as string;
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!endpointSecret) {
    console.warn("STRIPE_WEBHOOK_SECRET is not configured");
    return res.status(400).send("Webhook secret not configured");
  }

  try {
    const stripe = getStripe();
    const event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const userId = session.client_reference_id;
      
      console.log(`[Stripe Webhook] Checkout session completed for user: ${userId}`);
    }

    res.json({ received: true });
  } catch (err: any) {
    console.error(`Webhook Error: ${err.message}`);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

app.use(express.json());

app.post("/api/create-checkout-session", async (req, res) => {
  try {
    const { userId, email } = req.body;
    const stripe = getStripe();
    
    const hostHeader = req.headers.host ? `${req.protocol || 'https'}://${req.headers.host}` : '';
    const appUrl = process.env.APP_URL || hostHeader || `http://localhost:3000`;

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: 'Ploof Bedtime Unlimited',
              description: 'Endless bedtime adventures for your children',
            },
            unit_amount: 399,
            recurring: {
              interval: 'month'
            }
          },
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${appUrl}/?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${appUrl}/?checkout_canceled=true`,
      customer_email: email || undefined,
      client_reference_id: userId || undefined,
      metadata: {
        userId: userId || 'anonymous'
      }
    });

    res.json({ id: session.id, url: session.url });
  } catch (error: any) {
    console.error("Error creating checkout session:", error);
    res.status(500).json({ error: error.message || "Failed to create checkout session" });
  }
});

app.post("/api/verify-checkout-session", async (req, res) => {
  try {
    const { sessionId } = req.body;
    const stripe = getStripe();
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    
    if (session.payment_status === 'paid') {
      res.json({ success: true, userId: session.client_reference_id });
    } else {
      res.json({ success: false });
    }
  } catch (error: any) {
    console.error("Error verifying checkout session:", error);
    res.status(500).json({ error: error.message || "Failed to verify checkout session" });
  }
});

app.post("/api/report-issue", async (req, res) => {
  try {
    const { category, message, childName, favoriteAnimal } = req.body;
    console.log(`[USER ISSUE REPORTED] Category: ${category}, Message: ${message}`);
    
    await sendWebhookNotification('user_reported', { category, message, childName, favoriteAnimal });
    
    res.json({ success: true, message: "Thank you for your report! The Ploof helpers have been notified." });
  } catch (error) {
    console.error("Error reporting issue:", error);
    res.status(500).json({ error: "Failed to submit report" });
  }
});

app.post("/api/generate", async (req, res) => {
  let userAuth, subStatus;
  try {
    userAuth = await verifyUser(req);
    subStatus = await checkSubscriptionAndLimits(userAuth);
  } catch (e: any) {
    if (e.message === 'LimitReached') return res.status(403).json({ error: "Free limit reached. Please subscribe." });
    return res.status(401).json({ error: "Unauthorized" });
  }
  const { childName, favoriteAnimal, setting, magicalElement, storyLength } = req.body;
  try {
    let lengthInstruction = "Keep it a medium length, about 3-5 minutes of read time (approx 300-400 words).";
    if (storyLength === 'short') {
      lengthInstruction = "Keep it very short and sweet, about 1-2 minutes of read time (approx 150-200 words).";
    } else if (storyLength === 'long') {
      lengthInstruction = "Make it longer and more immersive, about 5-8 minutes of read time (approx 500-700 words).";
    }

    const prompt = `
You are a world-class children's book author like Beatrix Potter mixed with Pixar. 
Your job is to write an engaging, soothing bedtime story based on the user's inputs.

Follow these strict rules:
1. Pacing: Start engaging, but gradually make the tone more soothing, rhythmic, and sleepy toward the end of the story to help the child fall asleep.
2. Tone: Warm, magical, and comforting. No scary elements, monsters, or loud surprises.
3. Structure: Break the text into short, digestible paragraphs so it is incredibly easy for an exhausted parent to read aloud.
4. Vocabulary: Rich but accessible for a 4-8 year old. 
5. Formatting: Output clean HTML or Markdown with no extra conversational text before or after the story. Start directly with the title.
6. Length: ${lengthInstruction}

User Inputs:
- Child's Name: ${childName}
- Favorite Animal: ${favoriteAnimal}
- Setting: ${setting}
- Magical Element: ${magicalElement}
    `;

    let response;
    try {
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: prompt,
      });
    } catch (error: any) {
      console.warn("Primary model failed, trying fallback...", error.message);
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash',
        contents: prompt,
      });
    }

    res.json({ story: response.text });
    if (subStatus && typeof subStatus === 'object' && subStatus.isFree && !subStatus.isGuest) {
      await incrementUsage(userAuth, subStatus.currentCount);
    }
  } catch (error: any) {
    console.error("Error generating story:", error);
    await sendWebhookNotification('generation_failed', {
      childName,
      favoriteAnimal,
      error: error.message || error.toString()
    });
    res.status(500).json({ error: "Failed to generate story" });
  }
});

app.post("/api/continue", async (req, res) => {
  let userAuth, subStatus;
  try {
    userAuth = await verifyUser(req);
    subStatus = await checkSubscriptionAndLimits(userAuth);
  } catch (e: any) {
    if (e.message === 'LimitReached') return res.status(403).json({ error: "Free limit reached. Please subscribe." });
    return res.status(401).json({ error: "Unauthorized" });
  }
  const { childName, favoriteAnimal, setting, magicalElement, storyLength, previousStory } = req.body;
  try {
    let lengthInstruction = "Keep it a medium length, about 3-5 minutes of read time (approx 300-400 words).";
    if (storyLength === 'short') {
      lengthInstruction = "Keep it very short and sweet, about 1-2 minutes of read time (approx 150-200 words).";
    } else if (storyLength === 'long') {
      lengthInstruction = "Make it longer and more immersive, about 5-8 minutes of read time (approx 500-700 words).";
    }

    const prompt = `
You are a world-class children's book author like Beatrix Potter mixed with Pixar. 
Your job is to write a continuation (a next chapter or part 2) of a bedtime story based on the previous story provided and the original inputs.

Follow these strict rules:
1. Continuity: Continue seamlessly from the previous story. Keep the characters (child "${childName}" and companion "${favoriteAnimal}"), the setting ("${setting}"), and the magical elements, but take them on a gentle new adventure.
2. Pacing: Start engaging, but gradually make the tone more soothing, rhythmic, and sleepy toward the end of this chapter to help the child fall asleep.
3. Tone: Warm, magical, and comforting. No scary elements, monsters, or loud surprises.
4. Structure: Break the text into short, digestible paragraphs so it is incredibly easy for an exhausted parent to read aloud.
5. Vocabulary: Rich but accessible for a 4-8 year old. 
6. Formatting: Output clean HTML or Markdown with no extra conversational text before or after the story. Start directly with the next chapter title (e.g. "Chapter 2: [Title]").
7. Length: ${lengthInstruction}

Original Inputs:
- Child's Name: ${childName}
- Favorite Animal: ${favoriteAnimal}
- Setting: ${setting}
- Magical Element: ${magicalElement}

Previous Story Content:
${previousStory}
    `;

    let response;
    try {
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: prompt,
      });
    } catch (error: any) {
      console.warn("Primary model failed for continuation, trying fallback...", error.message);
      response = await ai.models.generateContent({
        model: 'gemini-3.1-flash',
        contents: prompt,
      });
    }

    res.json({ story: response.text });
  } catch (error: any) {
    console.error("Error continuing story:", error);
    await sendWebhookNotification('generation_failed', {
      childName,
      favoriteAnimal,
      error: `Continuation failed: ${error.message || error.toString()}`
    });
    res.status(500).json({ error: "Failed to continue story" });
  }
});
