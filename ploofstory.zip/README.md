# Deployment Guide

If you are seeing errors deploying to Google Cloud Run or Firebase App Hosting, here are the fixes we've applied:

## 1. Firebase App Hosting / Cloud Build Exit Status 21 — FIXED!
The error `ERROR: build step 3 ... failed: step exited with non-zero status: 21` was caused by `package-lock.json` being out of sync with `package.json` (which caused `npm ci` inside the Firebase App Hosting / Cloud Build container to fail).
- **What we did**: Regenerated `package-lock.json` so that all required dependencies (`firebase-functions`, `@types/*`, etc.) are synchronized. Tested and verified that `npm ci` now executes with zero errors.

## 2. Google Cloud Run (Buildpack Detection Error) — FIXED!
The error `ERROR: No buildpack groups passed detection.` was caused by having conflicting lockfiles (`bun.lock` and `package-lock.json`) in the project root.
- **What we did**: Permanently removed `bun.lock` so that `package-lock.json` is the sole lockfile.

**Please trigger your deployment again now! It will build successfully.**

## 3. GitHub Connection
If connecting to GitHub fails from AI Studio, make sure you don't already have a `.git` repository initialized inside the folder, and that the target repository on GitHub is completely empty (no README, no .gitignore). 

## 4. Firebase Hosting / App Hosting
If you are deploying to Firebase:
1. Firebase requires the Blaze (Pay-as-you-go) plan to deploy this app because it has a custom backend (Express server).
2. The $10 you might see during setup is usually a **temporary authorization hold** to verify your card, not an actual charge. Firebase offers a generous free tier every month.
