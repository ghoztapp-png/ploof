# Deployment Guide

If you are seeing errors deploying to Google Cloud Run or Firebase, here are the fixes we've applied:

## 1. Google Cloud Run (Buildpack Detection Error)
The error `ERROR: No buildpack groups passed detection.` was likely caused by having conflicting lockfiles (both `bun.lock` and `package-lock.json`). The `bun.lock` file has been removed to resolve this.

Additionally, a `Dockerfile` is now provided. If Cloud Run detects the `Dockerfile`, it will bypass buildpacks entirely and use Docker to build the app, which is much more reliable.

**Try clicking the deploy button or running your deployment again.**

## 2. GitHub Connection
If connecting to GitHub fails from AI Studio, make sure you don't already have a `.git` repository initialized inside the folder, and that the target repository on GitHub is completely empty (no README, no .gitignore). 

## 3. Firebase Hosting / App Hosting
If you are deploying to Firebase:
1. Firebase requires the Blaze (Pay-as-you-go) plan to deploy this app because it has a custom backend (Express server).
2. The $10 you might see during setup is usually a **temporary authorization hold** to verify the card, not an actual charge. You get a generous free tier every month.
